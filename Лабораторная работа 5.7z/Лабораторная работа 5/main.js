document.getElementById('myBtn').addEventListener('click', getData);

function getData() {
    

    fetch('https://randomuser.me/api/?results=10')
        .then(res => res.json())
        .then(data => {
            

            let author = data.results;
            

            let output = "<h2><center>Data</center></h2>";

            
            author.forEach(function (lists) {
                output += `
                <div class="container">
                    <div class="card mb-3" style="max-width: 540px;">
                       <div class="row g-0">
                          <div class="col-md-4">
                             <img src="${lists.picture.large}" class="img-fluid rounded-start" alt="...">
                          </div>
                       <div class="col-md-8">
                    <div class="card-body">
                       <h5 class="card-title">Name: ${lists.name.first}, Surname: ${lists.name.last} </h5>
                       <p class="card-text">Gender: ${lists.gender}</p>
                       <p class="card-text">Country: ${lists.location.country}, City: ${lists.location.city}</p>
                       <p class="card-text">Email ID: ${lists.email}</p>
                       <p class="card-text">DOB: ${lists.dob.date}</p>
                       <p class="card-text">Age: ${lists.dob.age}</p>
                       <p class="card-text">Phone Number: ${lists.cell}</p>
                    </div>
                  </div>
                 </div>
                 </div>
                </div> `;
            });

            document.getElementById('output').innerHTML = output;

        });
};


window.onload = function() {
    let preloader = document.getElementById('preloader');
    preloader.classList.add('hide-preloader');
    setInterval(function() {
          preloader.classList.add('preloader-hidden');
    }, 990);
}