import React from 'react'
import FetchUsers from './FetchUsers'

const App = () => {
  return (
    <>
      <h1 className="text-center bg-gray-900 text-white text-3xl pt-5 lg:text-6xl">
        React
      </h1>
      <FetchUsers />
    </>
  )
}

export default App
