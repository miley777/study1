import React from "react";

const MainPage = () => {
  return (
    <div className="p-4">
      <p className="fs-1">Free registration</p>
    </div>
  );
};

export default MainPage;
