import React from "react";
import Header from "./Header";

const Layout = () => {
  return (
    <header>
      <Header />
    </header>
  );
};

export default Layout;
